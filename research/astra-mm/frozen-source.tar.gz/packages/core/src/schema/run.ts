import { z } from 'zod';
import { DriftClass, Message, TargetRef, WorldState } from './common';

/**
 * Run records written by the runner. Keys are camelCase. A run is one spec, on one target, in one
 * mode, for one repeat.
 */

export const RunMode = z.enum(['T', 'F', 'P']);
export type RunMode = z.infer<typeof RunMode>;

/** `not_applicable`: a check whose subject the run never produced (a stage check with no stage record). */
export const Outcome = z.enum(['pass', 'fail', 'inconclusive', 'not_applicable']);
export type Outcome = z.infer<typeof Outcome>;

/** The fully resolved initial conditions of a block. */
export const ResolvedGiven = z.strictObject({
  prefix: z.array(Message),
  ledger: z.record(z.string(), z.unknown()),
  world: WorldState,
  vars: z.record(z.string(), z.unknown()),
  target: TargetRef,
  hash: z.string().min(1),
});
export type ResolvedGiven = z.infer<typeof ResolvedGiven>;

export const ToolCall = z.strictObject({
  id: z.string().optional(),
  label: z.string().min(1),
  input: z.unknown(),
  output: z.unknown().optional(),
  error: z.string().optional(),
  startedAt: z.string().optional(),
  latencyMs: z.number().nonnegative().optional(),
});
export type ToolCall = z.infer<typeof ToolCall>;

export const Cost = z.strictObject({
  usd: z.number().nonnegative().optional(),
  inputTokens: z.number().int().nonnegative().optional(),
  outputTokens: z.number().int().nonnegative().optional(),
});
export type Cost = z.infer<typeof Cost>;

/** Cost and latency an adapter can attach to one segment when its runtime reports them. */
const segmentMeasure = {
  cost: Cost.optional(),
  latencyMs: z.number().nonnegative().optional(),
};

/** One piece of what the agent produced in a block, in order. */
export const Segment = z.discriminatedUnion('type', [
  z.strictObject({ type: z.literal('text'), text: z.string(), ...segmentMeasure }),
  z.strictObject({
    type: z.literal('tool_call'),
    id: z.string().optional(),
    label: z.string().min(1),
    input: z.unknown(),
    ...segmentMeasure,
  }),
  z.strictObject({
    type: z.literal('tool_result'),
    id: z.string().optional(),
    label: z.string().min(1),
    output: z.unknown(),
    error: z.string().optional(),
    ...segmentMeasure,
  }),
  z.strictObject({
    type: z.literal('card'),
    name: z.string().min(1),
    data: z.unknown().optional(),
    ...segmentMeasure,
  }),
]);
export type Segment = z.infer<typeof Segment>;

/** A file the agent left in its workspace. */
export const ArtifactRef = z.strictObject({
  path: z.string(),
  kind: z.string().optional(),
  sha256: z.string().optional(),
  bytes: z.number().int().nonnegative().optional(),
});
export type ArtifactRef = z.infer<typeof ArtifactRef>;

/** What changed in the workspace during a block. */
export const WorkspaceDiff = z.strictObject({
  created: z.array(z.string()),
  changed: z.array(z.string()),
  deleted: z.array(z.string()),
});
export type WorkspaceDiff = z.infer<typeof WorkspaceDiff>;

/** One command the agent ran, with bounded output. `role` separates the agent's own process from the commands it ran. */
export const ExecutionRecord = z.strictObject({
  command: z.string(),
  role: z.enum(['agent', 'command']).optional(),
  exitCode: z.number().int(),
  stdout: z.string().optional(),
  stderr: z.string().optional(),
  startedAt: z.string().optional(),
  latencyMs: z.number().nonnegative().optional(),
  truncated: z.boolean().optional(),
  /** The approval policy's decision on this command and its cwd. Absent when no policy is set. */
  approval: z
    .strictObject({
      decision: z.enum(['allow', 'deny']),
      by: z.enum(['rule', 'default', 'approver', 'no-approver']),
      match: z.enum(['command', 'path']),
      subject: z.string(),
      pattern: z.string().optional(),
    })
    .optional(),
});
export type ExecutionRecord = z.infer<typeof ExecutionRecord>;

/**
 * What the agent's runtime did around the model: capabilities loaded, checks that fired, stages reached.
 * Runtime-specific events (a harness hook, a process step, a board write) are mapped onto these by its adapter.
 */
export const RuntimeTrace = z.strictObject({
  skills: z.array(z.strictObject({ name: z.string(), at: z.string().optional() })).optional(),
  guards: z
    .array(
      z.strictObject({
        name: z.string(),
        verdict: z.string(),
        at: z.string().optional(),
        /** What the guard printed and how it ended, when the runtime reports its output. */
        stdout: z.string().optional(),
        stderr: z.string().optional(),
        exitCode: z.number().int().optional(),
        /** The runtime's own word for how the run ended: success, blocking, cancelled, no_response. */
        outcome: z.string().optional(),
      }),
    )
    .optional(),
  stages: z.array(z.strictObject({ name: z.string(), at: z.string().optional() })).optional(),
  /** Files the agent read during the block, by path. Absent when the runtime does not report them. */
  references: z.array(z.strictObject({ path: z.string(), at: z.string().optional() })).optional(),
  /** The tools the runtime offered the agent in the block, by name. Absent when the runtime does not report them. */
  offered: z.array(z.string()).optional(),
  /** Helpers the agent dispatched during the block. Absent when the runtime does not report them. */
  subagents: z
    .array(z.strictObject({ name: z.string(), model: z.string().optional(), at: z.string().optional() }))
    .optional(),
});
export type RuntimeTrace = z.infer<typeof RuntimeTrace>;

/** One retry of a model or adapter call: which call, which attempt failed, why, and how long it waited. */
export const RetryEvent = z.strictObject({
  call: z.string().min(1),
  /** The attempt that failed, counted from 1. */
  attempt: z.number().int().min(1),
  status: z.number().int().optional(),
  reason: z.string(),
  delayMs: z.number().nonnegative(),
  /** What the server's Retry-After asked, when it sent one. */
  retryAfterMs: z.number().nonnegative().optional(),
  at: z.string().optional(),
});
export type RetryEvent = z.infer<typeof RetryEvent>;

/** Everything observed in one block. */
export const Observed = z.strictObject({
  segments: z.array(Segment),
  text: z.string(),
  toolCalls: z.array(ToolCall),
  runtime: RuntimeTrace.optional(),
  artifacts: z.array(ArtifactRef).optional(),
  workspaceDiff: WorkspaceDiff.optional(),
  executions: z.array(ExecutionRecord).optional(),
  /** The sandbox the block ran in, when the adapter owns one; reports say 'weak isolation' from this field. */
  sandbox: z
    .strictObject({ kind: z.string(), isolation: z.enum(['strong', 'weak']), root: z.string().optional() })
    .optional(),
  cost: Cost,
  latencyMs: z.number().nonnegative(),
  /** Every retry the block's calls took, the adapter's own and the runner's, in order. Absent when none. */
  retries: z.array(RetryEvent).optional(),
  raw: z.unknown().optional(),
});
export type Observed = z.infer<typeof Observed>;

export const Vote = z.strictObject({
  judge: z.string().min(1),
  outcome: Outcome,
  score: z.number().optional(),
  reasoning: z.string().optional(),
  /** Every retry the judge's call took. Absent when none. */
  retries: z.array(RetryEvent).optional(),
});

/** One check's result on one block. Machine verdicts are final; judge verdicts carry their votes. */
export const Verdict = z.strictObject({
  id: z.string().min(1),
  kind: z.enum(['machine', 'judge']),
  name: z.string().min(1),
  gating: z.boolean(),
  outcome: Outcome,
  score: z.number().optional(),
  evidence: z.string(),
  reasoning: z.string().optional(),
  judge: z.strictObject({ cls: z.enum(['system1', 'system2']), votes: z.array(Vote) }).optional(),
});
export type Verdict = z.infer<typeof Verdict>;

export const BlockResult = z.strictObject({
  index: z.number().int().min(0),
  blockId: z.string().optional(),
  injected: z.boolean().optional(),
  givenHash: z.string().min(1),
  observed: Observed,
  verdicts: z.array(Verdict),
  stageObserved: z.string().optional(),
  ledgerCheck: z.strictObject({ ok: z.boolean(), contradictions: z.array(z.string()) }),
  drift: z.array(DriftClass),
  pass: z.boolean(),
});
export type BlockResult = z.infer<typeof BlockResult>;

export const Succession = z.strictObject({
  firstDriftBlock: z.number().int().min(0).optional(),
  driftCount: z.number().int().min(0),
  driftRate: z.number().min(0).max(1),
  longestClean: z.number().int().min(0),
  minOverBlocks: z.boolean(),
});

export const Recovery = z.strictObject({
  injectedAt: z.number().int().min(0),
  turnsToRecover: z.number().int().min(0).optional(),
  label: z.enum(['immediate', 'late', 'never']),
  collateral: z.number().int().min(0),
  safeAction: z.boolean().optional(),
  clarified: z.boolean().optional(),
});

/**
 * What the runner reports as a run goes, in order. A model call carries its tokens, cost and latency when the adapter
 * gives them; its start is the reply time less its latency.
 */
export const RunEvent = z.discriminatedUnion('type', [
  z.strictObject({ type: z.literal('block_start'), index: z.number().int().min(0), at: z.string().min(1) }),
  z.strictObject({
    type: z.literal('model_call'),
    index: z.number().int().min(0),
    inputTokens: z.number().int().nonnegative().optional(),
    outputTokens: z.number().int().nonnegative().optional(),
    usd: z.number().nonnegative().optional(),
    latencyMs: z.number().nonnegative().optional(),
    startedAt: z.string().min(1),
    at: z.string().min(1),
  }),
  z.strictObject({
    type: z.literal('tool_call'),
    index: z.number().int().min(0),
    label: z.string().min(1),
    error: z.string().optional(),
    at: z.string().min(1),
  }),
  z.strictObject({ type: z.literal('retry'), index: z.number().int().min(0), at: z.string().min(1) }),
  z.strictObject({
    type: z.literal('block_end'),
    index: z.number().int().min(0),
    pass: z.boolean(),
    at: z.string().min(1),
  }),
  z.strictObject({
    type: z.literal('run_end'),
    status: z.enum(['completed', 'failed', 'stopped']),
    at: z.string().min(1),
  }),
]);
export type RunEvent = z.infer<typeof RunEvent>;

export const RunResult = z.strictObject({
  runId: z.string().min(1),
  specId: z.string().min(1),
  specHash: z.string().min(1),
  target: TargetRef,
  mode: RunMode,
  repeat: z.number().int().min(0),
  perturbationId: z.string().optional(),
  status: z.enum(['completed', 'failed', 'stopped']),
  /** The verdict the spec's end gave the run, when the script ended with one. */
  endVerdict: z.enum(['success', 'failure']).optional(),
  error: z.string().optional(),
  blocks: z.array(BlockResult),
  succession: Succession,
  recovery: Recovery.optional(),
  endState: z
    .strictObject({
      match: z.boolean(),
      diff: z.array(z.strictObject({ field: z.string(), expected: z.unknown(), observed: z.unknown() })),
    })
    .optional(),
  cost: z.number().nonnegative(),
  latencyMs: z.number().nonnegative(),
  startedAt: z.string().min(1),
  finishedAt: z.string().min(1),
  cacheHit: z.boolean(),
  /** The events the run reported, in order, when the run recorded them. Absent otherwise. */
  events: z.array(RunEvent).optional(),
});
export type RunResult = z.infer<typeof RunResult>;

export const JudgeConfig = z.strictObject({
  mode: z.enum(['system1', 'hybrid', 'llm']),
  judges: z.array(z.string().min(1)),
  assignment: z.string().optional(),
});

/** One immutable registry version a campaign ran with: a dataset of specs or a prompt. */
export const RegistrySource = z.strictObject({
  kind: z.enum(['dataset', 'prompt']),
  name: z.string().min(1),
  version: z.number().int().min(1),
  hash: z.string().regex(/^[0-9a-f]{64}$/),
});
export type RegistrySource = z.infer<typeof RegistrySource>;

/** A campaign pins spec versions, targets, modes and repeats. A re-run is a new campaign. */
export const Campaign = z.strictObject({
  campaignId: z.string().min(1),
  specs: z
    .array(
      z.strictObject({
        id: z.string().min(1),
        hash: z.string().min(1),
        /** The one target this spec runs on. Without it, the spec runs on every target of the campaign. */
        target: TargetRef.optional(),
      }),
    )
    .min(1),
  targets: z.array(TargetRef).min(1),
  modes: z.array(RunMode).min(1),
  repeats: z.strictObject({
    T: z.number().int().min(0),
    F: z.number().int().min(0),
    P: z.number().int().min(0),
  }),
  budgetUsd: z.number().nonnegative(),
  judge: JudgeConfig,
  createdAt: z.string().min(1),
  /** The registry versions the campaign ran: the dataset its specs came from, the prompts it pinned. */
  sources: z.array(RegistrySource).optional(),
});
export type Campaign = z.infer<typeof Campaign>;
